package main;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LibrarySystem {
    private List<Item> items;
    private FileHandler fileHandler;
    private Scanner scanner;

    public LibrarySystem() {
        this.items = new ArrayList<>();
        this.fileHandler = new TextFileHandler();
        this.scanner = new Scanner(System.in);
    }

    public void displayMenu() {
        while (true) {
            System.out.println("\n=== Library Management System ===");
            System.out.println("1. Add new Book");
            System.out.println("2. Add new DVD");
            System.out.println("3. Remove item");
            System.out.println("4. List all items");
            System.out.println("5. Search by title");
            System.out.println("6. Save to file");
            System.out.println("7. Load from file");
            System.out.println("8. Exit");
            
            System.out.println("Enter your choice:");  // Changed print() to println() to move to a new line
    
            int choice = Integer.parseInt(scanner.nextLine());
    
            switch (choice) {
                case 1:
                    addBook();
                    break;
                case 2:
                    addDVD();
                    break;
                case 3:
                    removeItem();
                    break;
                case 4:
                    listAllItems();
                    break;
                case 5:
                    searchByTitle();
                    break;
                case 6:
                    saveToFile();
                    break;
                case 7:
                    loadFromFile();
                    break;
                case 8:
                    System.out.println("Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }    

    private void addBook() {
        System.out.println("Enter book ID:");
        String id = scanner.nextLine();
    
        System.out.println("Enter title:");
        String title = scanner.nextLine();
    
        System.out.println("Enter author:");
        String author = scanner.nextLine();
    
        items.add(new Book(id, title, author));
        System.out.println("Book added successfully.");
    }
    

    private void addDVD() {
        System.out.println("Enter DVD ID:");
        String id = scanner.nextLine();
    
        System.out.println("Enter title:");
        String title = scanner.nextLine();
    
        System.out.println("Enter duration (minutes):");
        int duration = Integer.parseInt(scanner.nextLine()); // Use nextLine() to avoid input issues
    
        items.add(new DVD(id, title, duration));
        System.out.println("DVD added successfully.");
    }
    

    private void removeItem() {
        System.out.print("Enter item ID to remove: ");
        String id = scanner.nextLine();
        items.removeIf(item -> item.getId().equalsIgnoreCase(id));
        System.out.println("Item removed successfully.");
    }

    private void listAllItems() {
        if (items.isEmpty()) {
            System.out.println("No items in the system.");
        } else {
            for (Item item : items) {
                System.out.println(item);
            }
        }
    }

    private void searchByTitle() {
        System.out.print("Enter title to search for: ");
        String title = scanner.nextLine().toLowerCase();
        boolean found = false;
        for (Item item : items) {
            if (item.getTitle().toLowerCase().contains(title)) {
                System.out.println(item);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No items found with that title.");
        }
    }

    private void saveToFile() {
        System.out.println("Enter filename to save:");  // Changed to println() for a new line
        String filename = scanner.nextLine();
        fileHandler.saveItems(filename, items);  // Save items
        System.out.println("Items saved to file successfully.\n"); // Added an extra newline for better spacing
    }
    
    

    private void loadFromFile() {
        System.out.print("Enter filename to load: ");
        String filename = scanner.nextLine();
        items = fileHandler.loadItems(filename);
    }
}
