package main;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class TextFileHandler implements FileHandler {

    @Override
    public void saveItems(String filename, List<Item> items) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Item item : items) {
                if (item instanceof Book) {
                    writer.write("BOOK;" + item.getId() + ";" + item.getTitle() + ";" + ((Book) item).getAuthor());
                } else if (item instanceof DVD) {
                    writer.write("DVD;" + item.getId() + ";" + item.getTitle() + ";" + ((DVD) item).getDuration());
                }
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving items to file.");
        }
    }

    @Override
    public List<Item> loadItems(String filename) {
        List<Item> items = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 4) {
                    if (parts[0].equals("BOOK")) {
                        items.add(new Book(parts[1], parts[2], parts[3]));
                    } else if (parts[0].equals("DVD")) {
                        items.add(new DVD(parts[1], parts[2], Integer.parseInt(parts[3])));
                    }
                }
            }
            System.out.println("Items loaded from file successfully.");
        } catch (IOException e) {
            System.out.println("Error loading items from file.");
        }
        return items;
    }
}
