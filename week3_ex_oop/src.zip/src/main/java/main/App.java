package main;

import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Ask for the zoo's name
        System.out.println("Please, name the zoo:");
        String zooName = scanner.nextLine().trim();

        Zoo zoo = new Zoo(zooName);
        

        
        while (true) {
            System.out.println("1) Create a new animal, 2) List all animals, 3) Run animals, 0) End the program");
            // Taking choice from user
            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine().trim()); // Read and parse choice directly
            } catch (NumberFormatException e) {
                System.out.println("Wrong input value.");
                continue;
            }
            // Switch case to perform different operations
            switch (choice) {
                case 1:
                    System.out.print("What species?\n");
                    //System.out.println();
                    String species = scanner.nextLine().trim(); // Read species and trim whitespace

                    System.out.print("Enter the name of the animal:\n");
                    String name = scanner.nextLine().trim(); // Read name and trim whitespace

                    System.out.print("Enter the age of the animal:\n");
                    int age = Integer.parseInt(scanner.nextLine().trim()); // Read and parse age directly

                    // Add animal to the zoo
                    zoo.addAnimal(species, name, age);
                    break;

                case 2:
                    // List all animals
                    zoo.listAnimals();
                    break;

                case 3:
                    System.out.print("How many laps?\n");
                    int laps = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline character

                    // Run all animals
                    zoo.animalsRun(laps);
                    break;

                case 0:
                    System.out.println("Thank you for using the program.");
                     // Close the scanner before exiting
                    scanner.close();
                    return; // Exit the program
                    

                default:
                    System.out.println("Wrong input value");
                    
                    break;
            }
        }
    }
}