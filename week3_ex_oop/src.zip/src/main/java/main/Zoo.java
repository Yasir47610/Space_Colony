package main;

import java.util.ArrayList;

public class Zoo {
    private ArrayList<Animal> animals;
    private String name;

    public Zoo(String name) {
        this.name = name;
        animals = new ArrayList<>();
    }

    public void addAnimal(String species, String name, int age) {
        Animal animal = new Animal(name, species, age);
        animals.add(animal);
        // System.out.println(animal.getName() + " has been added to the zoo.");
    }

    public void listAnimals() {
        if (animals.isEmpty()) {
            System.out.println(name + " contains no animals.");
            return;
        }
        System.out.println(name + " contains the following animals:");
        for (Animal animal : animals) {
            System.out.println(animal.getSpecies() + ": " + animal.getName() + ", " + animal.getAge() + " years");
        }
    }

    public void animalsRun(int laps) {
        for (Animal animal : animals) {
            for (int i = 0; i < laps; i++) {
                System.out.println(animal.getName() + " runs really fast!");
            }
        }
    }
}