package main;

import java.util.ArrayList;

public class Bookshelf {
    private ArrayList<Book> books = new ArrayList<Book>();
    

    // add a book to the bookshelf/
    public void addBook(Book book) {
        books.add(book);
    }
    // remove a book from the bookshelf/
    public boolean removeBook(Book book) {
        return books.remove(book);
    }
    /*displaying all the books */
    public void displayBooks() {
        System.out.println("Books on the shelf:");
        for (Book book : books) {
            
            System.out.println("Title: " + book.getTitle() + ", Author: "+ book.getAuthor().getName() + ", ISBN: " + book.getIsbn());
        }

    }
}    
