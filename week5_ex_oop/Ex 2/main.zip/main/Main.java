package main;



public class Main 
{
    public static void main( String[] args )
    {
        Author author = new Author("George Orwell", "British");
        Book book1 = new Book("1984", author, "978-0451524935");
        Book book2 = new Book("Animal Farm", author, "978-0451526342");
        Bookshelf bookshelf = new Bookshelf();
        bookshelf.addBook(book1);
        bookshelf.addBook(book2);
        System.out.println("Initial bookshelf contents:");
        bookshelf.displayBooks();

        System.out.println("\nRemoving 1984...");
        bookshelf.removeBook(book1);
        System.out.println("\nUpdated bookshelf contents:");
       
        bookshelf.displayBooks();

        
    }
}
