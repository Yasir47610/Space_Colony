package main;

/**
 * Hello world!
 *
 */
public class Main
{
    public static void main( String[] args )
    {
        System.out.println( "Course Information:" );
        Course course1 = new Course("Programming 101", 30);
        System.out.println("Name: " + course1.getCourseName());
        System.out.println("Maximum students: " + course1.getMaxStudents());
        System.out.println();
        System.out.println( "Student Information:" );
        
        Student student1 = new Student("John Smith", "S001");
        Student student2 = new Student("Alice Johnson", "S002");
        System.out.println("Student 1 - Name: " + student1.getName() +", ID: "+ student1.getStudentId());
        System.out.println("Student 2 - Name: " + student2.getName() +", ID: "+ student2.getStudentId());



    }
}
