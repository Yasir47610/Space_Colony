package week6;
import java.util.ArrayList;
import java.util.Scanner;


public class App 
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Vehicles> vehicles = new ArrayList<>();
        boolean running = true;

        while (running) {
            System.out.println("1) Create new vehicle, 2) List vehicles 3) Drive cars, 4) Fly planes, 5) Sail the ships, 0) End the program");
            int choice = scanner.nextInt();
              

            switch (choice) {
                case 1:
                    scanner.nextLine();
                    System.out.println("Which vehicle do you want to build? 1) car, 2) plane, 3) ship");
                    int vehicleChoice = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.println("Who is the manufacturer?");
                    String manufacturer = scanner.nextLine();
                    System.out.println("What is the model of the vehicle?");
                    String model = scanner.nextLine();
                    System.out.println("What is the top speed?");
                    int maxSpeed = scanner.nextInt();
                    scanner.nextLine();  

                    if (vehicleChoice == 1) {
                        vehicles.add(new Car(manufacturer, model, maxSpeed));
                    } else if (vehicleChoice == 2) {
                        vehicles.add(new Plane(manufacturer, model, maxSpeed));
                    } else if (vehicleChoice == 3) {
                        vehicles.add(new Ship(manufacturer, model, maxSpeed));
                    }
                    break;

                case 2:
                for (Vehicles vehicle : vehicles) {
                    System.out.println(vehicle);
                    if (vehicle instanceof Car) {
                        System.out.println("Engine: V8 (300 HP) \n");
                    } else if (vehicle instanceof Plane) {
                        System.out.println("Engine: Jet engine (500 HP) \n");
                    } else if (vehicle instanceof Ship) {
                        System.out.println("Engine: Wärtsilä Super (1000 HP) \n");
                    }
                }
                break;

                case 3:
                    for (Vehicles vehicle : vehicles) {
                        if (vehicle instanceof Car) {
                            ((Car) vehicle).drive();
                        }
                    }
                    break;

                case 4:
                    for (Vehicles vehicle : vehicles) {
                        if (vehicle instanceof Plane) {
                            ((Plane) vehicle).fly();
                        }
                    }
                    break;

                case 5:
                    for (Vehicles vehicle : vehicles) {
                        if (vehicle instanceof Ship) {
                            ((Ship) vehicle).sail();
                        }
                    }
                    break;

                case 0:
                    System.out.println("Thank you for using the program.");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid choice, please try again.");
                    break;
            }
        }

        scanner.close();
    }
}

