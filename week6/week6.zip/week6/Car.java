package week6;

public class Car extends Vehicles {
    public Car(String manufacturer, String model, int maxSpeed ){
        super("Car",manufacturer, model, maxSpeed);
    }

    public void drive(){
            System.out.println(manufacturer + " " + model + " is driving on the road!");
    }

}
