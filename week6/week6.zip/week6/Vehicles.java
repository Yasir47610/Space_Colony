package week6;

public abstract class Vehicles {
    @SuppressWarnings("unused")
    private String type;
    protected String manufacturer;
    protected String model;
    protected int maxSpeed;
    @SuppressWarnings("unused")
    private Engine engine;

    public Vehicles(String type, String manufacturer, String model, int maxSpeed){
        this.type = type;
        this.manufacturer = manufacturer;
        this.model = model;
        this.maxSpeed = maxSpeed;
    }

    public String toString(){
        String result = "";

        if (this instanceof Car) {
            result += "Car: " + manufacturer + " " + model;
        } else if (this instanceof Plane) {
            result += "Plane: " + manufacturer + " " + model;
        } else if (this instanceof Ship) {
            result += "Ship: " + manufacturer + " " + model;
        }

        result += "\nMax Speed: " + maxSpeed + " km/h";

        return result;
    }

}
