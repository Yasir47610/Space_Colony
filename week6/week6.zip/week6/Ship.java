package week6;

public class Ship extends Vehicles {
    
        
    public Ship(String manufacturer, String model, int maxSpeed) {
    super("Ship",manufacturer, model, maxSpeed);
    }
            
    public void sail() {
    System.out.println(manufacturer + " " + model + " is sailing on the sea!");
    }

    

}
