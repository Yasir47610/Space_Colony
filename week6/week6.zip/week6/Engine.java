package week6;

public class Engine {
    private String name;
    private int power;

    public Engine(String name, int power){
        this.name = name;
        this.power = power;
    }

    public String toString(){
        return name + " (" + power + " HP)";
    }

}