package week6;

public class Plane extends Vehicles {
    public Plane(String manufacturer, String model, int maxSpeed) {
        super("Plane",manufacturer, model, maxSpeed);
    }

    public void fly() {
        System.out.println(manufacturer + " " + model + " is flying in the sky!");
        
    }

}
