package main;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class App {
    private static List<Student> students = new ArrayList<>(); // Declare and initialize the list
    private static University university = new University(); // Create an instance of University
    private static Calculator calculator = new Calculator(); // Create an instance of Calculator

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Initialize Scanner

        // Main loop for the application
        while (true) {
            System.out.println("1) Add student, 2) List students, 3) Add course completion for student, 4) List course completions of student, 5) Calculate the average of course completions, 6) Calculate median of course completions, 7) Save students to file, 8) Load students from file, 0) End the program");

            // Taking choice from user
            int choice;
            try {
                choice = Integer.parseInt(scanner.nextLine().trim()); // Read and parse choice directly
            } catch (NumberFormatException e) {
                System.out.println("Wrong input value.");
                continue; // Skip to the next iteration
            }

            // Switch case to perform different operations
            switch (choice) {
                case 0:
                    System.out.println("Thank you for using the program.");
                    scanner.close(); // Close the scanner before exiting
                    return; // Exit the program

                case 1:
                    System.out.println("What is the name of the student?");
                    String name = scanner.nextLine().trim(); // Read the full name (including spaces)

                    System.out.println("What is the student number of the student?");
                    String studentNumber = scanner.nextLine().trim(); // Read the student number

                    Student student = new Student(name, studentNumber); // Create a new student
                    students.add(student); // Add student to the list
                    university.addStudent(student); // Add student to the university
                    break;

                case 2: // List all students
                    for (int i = 0; i < students.size(); i++) { // Use index in the loop
                        System.out.println(students.get(i).listStudents(i)); // Call listStudents with index
                    }
                    break;

                case 3:
                    for (int i = 0; i < students.size(); i++) { // Use index in the loop
                        System.out.println(students.get(i).listStudents(i)); // Call listStudents with index
                    }   
                    System.out.println("Which student?");
                    int studentIndex;
                    try {
                        studentIndex = Integer.parseInt(scanner.nextLine().trim()); // Read the student index
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid index. Please enter a number.");
                        continue; // Skip to the next iteration
                    }

                    System.out.println("What is the name of the course?");
                    String course = scanner.nextLine().trim(); // Read the course name

                    System.out.println("What is the grade of the course?");
                    int grade;
                    try {
                        grade = Integer.parseInt(scanner.nextLine().trim()); // Read and parse the grade
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid grade. Please enter a number.");
                        continue; // Skip to the next iteration
                    }

                    students.get(studentIndex).addGrade(course, grade); // Call addGrade with course and grade
                    break;

                case 4: // List course completions for a specific student
                    for (int i = 0; i < students.size(); i++) { // Use index in the loop
                        System.out.println(students.get(i).listStudents(i)); // Call listStudents with index
                    }
                    System.out.println("Which student?");
                    int indexForCourses;
                    try {
                        indexForCourses = Integer.parseInt(scanner.nextLine().trim()); // Read the student index
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid index. Please enter a number.");
                        continue; // Skip to the next iteration
                    }

                    List<Grade> gradesList = students.get(indexForCourses).getGrades(); // Get grades
                    for (Grade gradeObj : gradesList) {
                        System.out.println(gradeObj.getCourse() + ": " + gradeObj.getGrade());
                    }
                    break;

                case 5: // Calculate the average of course completions
                    for (int i = 0; i < students.size(); i++) { // Use index in the loop
                        System.out.println(students.get(i).listStudents(i)); // Call listStudents with index
                    }
                    System.out.println("Which student?");
                    int indexForAverage;
                    try {
                        indexForAverage = Integer.parseInt(scanner.nextLine().trim()); // Read the student index
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid index. Please enter a number.");
                        continue; // Skip to the next iteration
                    }

                    double average = calculator.getAverageGrade(students.get(indexForAverage));
                    System.out.println("Average is " + average);
                    break;

                case 6: // Calculate the median of course completions
                    for (int i = 0; i < students.size(); i++) { // Use index in the loop
                        System.out.println(students.get(i).listStudents(i)); // Call listStudents with index
                    }
                    System.out.println("Which student?");
                    int indexForMedian;
                    try {
                        indexForMedian = Integer.parseInt(scanner.nextLine().trim()); // Read the student index
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid index. Please enter a number.");
                        continue; // Skip to the next iteration
                    }

                    double median = calculator.getMedianGrade(students.get(indexForMedian));
                    System.out.println("Median is " +  median);
                    break;

                case 7: // Save students to file
                    university.saveToFile(); // Save to the fixed filename
                    break;

                case 8: // Load students from file
                    university.loadFromFile(); // Load from the fixed filename
                    students = university.getStudents(); // Update the local students list
                    break;

                default:
                    System.out.println("Wrong input value.");
                    break;
            }
        }
    }
}