package main;

import java.util.ArrayList; // Import ArrayList
import java.util.Collections;
import java.util.List;

public class Calculator {
    public double getAverageGrade(Student student) {
        List<Grade> grades = student.getGrades(); // Get the list of grades
        if (grades.isEmpty()) {
            return 0.0; // Return 0 if there are no grades
        }
        int sum = 0;
        for (Grade grade : grades) {
            sum += grade.getGrade(); // Sum the grades
        }
        return (double) sum / grades.size(); // Calculate and return the average
    }

    public double getMedianGrade(Student student) {
        List<Grade> grades = student.getGrades(); // Get the list of grades
        if (grades.isEmpty()) {
            return 0.0; // Return 0 if there are no grades
        }
        List<Integer> gradeValues = new ArrayList<>(); // Create a new list for integer grades
        for (Grade grade : grades) {
            gradeValues.add(grade.getGrade()); // Extract grades from Grade objects
        }
        Collections.sort(gradeValues); // Sort grades
        int size = gradeValues.size();
        if (size % 2 == 0) {
            return (gradeValues.get(size / 2 - 1) + gradeValues.get(size / 2)) / 2.0; // Average of two middle grades
        } else {
            return gradeValues.get(size / 2); // Return the middle grade
        }
    }
}