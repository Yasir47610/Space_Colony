package main;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class University {
    private List<Student> students;
    private final String filename = "students.dat"; // Fixed filename for saving/loading

    public University() {
        students = new ArrayList<>(); // Initialize the list of students
    }

    public void addStudent(Student student) {
        students.add(student); // Add a student to the list
    }

    public List<Student> getStudents() {
        return students; // Return the list of students
    }

    public void saveToFile() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(students); // Serialize and save student data to a file
            System.out.println("Students saved to file.");
        } catch (IOException e) {
            System.out.println("Error saving to file: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked") // Suppress unchecked cast warning
    public void loadFromFile() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filename))) {
            students = (List<Student>) ois.readObject(); // Load and deserialize student data from a file
            System.out.println("Students loaded from file.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading from file: " + e.getMessage());
        }
    }
}