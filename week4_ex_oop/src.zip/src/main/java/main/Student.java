package main;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Student implements Serializable {
    private String name;
    private String studentNumber; // Change to String to match input type
    private List<Grade> grades; // List to hold grades

    public Student(String name, String studentNumber) {
        this.name = name;
        this.studentNumber = studentNumber;
        this.grades = new ArrayList<>(); // Initialize the grades list
    }

    public String getName() {
        return name;
    }

    public String getStudentNumber() {
        return studentNumber; // Change return type to String
    }

    public String listStudents(int index) {
        return index + ": " + studentNumber + ": " + name;
    }

    public void addGrade(String course, int grade) {
        grades.add(new Grade(course, grade)); // Add a new Grade object to the list
    }

    public List<Grade> getGrades() {
        return grades; // Return the list of grades
    }
}